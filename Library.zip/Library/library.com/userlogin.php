<?php 

//echo md5('AdminGoTigers'); exit();
require_once './lib/init.php';

/* link the database */
$mysql = new mysql();
$mysql->connect();

if(empty($_POST)) {
	require(ROOT . '/view/front/service.html');
	} else {
	$user['name'] = trim($_POST['Username']);
	if(empty($user['name'])) {
		error('Please enter a card ID!');
	}

	$user['password'] = trim($_POST['Password']);
	if(empty($user['password'])) {
		error('Please enter a password!');
	}

	//$sql = "select * from user where name='$user[name]' and password='$user[password]'";
	$table = 'Borrower';
	$where = 'Card_id ='. $user['name'];
	$mysql->select($table, null,$where);
	$row = $mysql->fetchArray();
	//print_r($row);exit();
	if(!$row) {
		error('The cardID is not exit!');
	} else {
		if(md5($user['password'].$row['salt']) === $row['Password']){
			setcookie('name' , $user['name']);
			setcookie('ccode' , cCode($user['name']));
			header('Location: usermanage.php');
		} else {
			error('Sorry, the password is wrong!');
		}
	}
}

$mysql->close();
?>
<?php 

setcookie('name',null,0);
header('Location: administratorlogin.php');



?>
<?php

require_once './lib/init.php';
/* link the database */

if(!acc()) {
	header('Location: admin.php');
	} else {
	$mysql = new mysql();
	$mysql->connect();
	date_default_timezone_set('EST');
	// echo $_GET['table'];exit();
	if(!empty($_GET['table'])){
		$table = trim($_GET['table']);
		$mysql->select($table);
		$row = $mysql->fetchAll();
		$mysql->showcolums($table);
		$colum = $mysql->fetchAll();
		// print_r($colum);print_r($row);exit();
		require_once ROOT.'/lib/PHPExcel/Classes/PHPExcel.php';
		$objPHPExcel=new PHPExcel();
		//set the excel colum
		$i = 'A';
		$m = $i;
		$k = 1;
		foreach ($colum as $v1) {
            foreach ($v1 as $key => $v2) {
              $m = $i;
              $objPHPExcel->setActiveSheetIndex(0)->setCellValue("$i$k","$v2");
              $i++;
              echo $i, $v2;
              echo '<br />';
            }     
        }
        //set the backgroud color
        // echo $m;exit();
        $objPHPExcel->getActiveSheet()->getStyle( "A1:$m$k")->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID);
		$objPHPExcel->getActiveSheet()->getStyle( "A1:$m$k")->getFill()->getStartColor()->setARGB('FF808080');

		//set the value
		$k = 1;
        foreach ($row as $v3) {
        	$j = 'A';
        	$k++;
            foreach ($v3 as $key => $v4) {
               $objPHPExcel->setActiveSheetIndex(0)->setCellValue($j.$k,$v4);
               $j++;
            }
        }

        //Set default fonts
		$objPHPExcel->getDefaultStyle()->getFont()->setName( 'Arial');
		$objPHPExcel->getDefaultStyle()->getFont()->setSize(12);

		//Set the column width
		$objPHPExcel->getActiveSheet()->getDefaultColumnDimension()->setWidth(14);
		$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(20);

		//Set up in the middle
		$objPHPExcel->getDefaultStyle()->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
		$objPHPExcel->getDefaultStyle()->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);

		$objPHPExcel->getActiveSheet() -> setTitle("$table");
		$objPHPExcel-> setActiveSheetIndex(0);

		$objWriter=PHPExcel_IOFactory::createWriter($objPHPExcel,'Excel2007');
		$filename = $table . '_backlist_'. date("Y-m-d-H-i-s");
		$file_type = "vnd.ms-excel";
		$file_ending = "xlsx";
		ob_end_clean();
		header("Content-Type: application/$file_type;charset=gbk");
		header('Content-Type: application/octet-stream');
		// header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
		header('Content-Disposition: attachment; filename="' . $filename . ".$file_ending");
		header('Cache-Control: max-age=0');
		$objWriter -> save('php://output');
		exit();

		// $phpexcel->getActiveSheet()->setTitle("$table");
		
		// header("Content-Type: application/$file_type;charset=gbk");
		// header("Content-Disposition: attachment; filename=".$savename.".$file_ending");
		// header("Pragma: no-cache");
		// $sep = "\t";
		// foreach ($colum as $v1) {
  //           foreach ($v1 as $key => $v2) {
  //             echo $v2 . "\t";
  //           }     
  //       }
  //       print("\n");
  //       foreach ($row as $v3) {
  //       	$schema_insert = "";
  //           foreach ($v3 as $key => $v4) {
  //             if(!isset($v4)) $schema_insert .= "NULL".$sep;
  //             else if ($v4 != "") $schema_insert .= "$v4".$sep;
  //             else $schema_insert .= "".$sep;
  //           }
  //           $schema_insert = str_replace($sep."$", "", $schema_insert);
  //           $schema_insert .= "\t";
  //           print(trim($schema_insert));
  //           print "\n"; 
  //       }
  //       return (true);
	}

	if(!empty($_FILES['backlist'])){
		$fileArray = $_FILES['backlist'];
		$upload_dir = ROOT . "/upload/";
		$nowTime = date("Y-m-d-H-i-s", time());
		if($fileArray['error'] == UPLOAD_ERR_OK){
			$temp_name = $fileArray['tmp_name'];
			$file_name = 'Uploadtime_'.$nowTime.'_'.$fileArray['name'];
			move_uploaded_file($temp_name, $upload_dir.$file_name);
		}else{
			error4('Uploading file failed'); 
		}
		
		require_once  ROOT.'/lib/PHPExcel/Classes/PHPExcel.php';
		require_once  ROOT.'/lib/PHPExcel/Classes/PHPExcel/IOFactory.php';
		$file_path = $upload_dir.$file_name; 
		$ext = strtolower(pathinfo($file_path,PATHINFO_EXTENSION));
		if($ext == 'xlsx'){
		    $objReader=PHPExcel_IOFactory::createReader('Excel2007');
		    $objPHPExcel = $objReader->load($file_path,'utf-8');
		}elseif($ext == 'xls'){
		    $objReader=PHPExcel_IOFactory::createReader('Excel5');
		    $objPHPExcel = $objReader->load($file_path,'utf-8');
		}
		$sheet = $objPHPExcel->getSheet(0);
		$highestRow = $sheet->getHighestRow(); // get the total row
		$highestColumn = $sheet->getHighestColumn(); // get the total column
		$Table = $objPHPExcel->getSheetNames();
		$table = $Table[0];
		// echo $highestColumn; exit();
		// echo $table;exit;
		$mysql->delete($table);
		$i = 1;
		$m = 0;
		$column = array();
		for ($k = 'A'; $k <= $highestColumn; $k++) {
		        $col = $objPHPExcel->getActiveSheet()->getCell("$k$i")->getValue();//read the colum
		        if($col != null){
		        	$column[$m] = $col;
		     	    $m++;
		        }
		        
		}
		// print_r($column); echo $m; exit;
		// $strs = explode("\\", $column);
		for($j=2;$j<=$highestRow;$j++) {
		    $str = array();
		    $k = 'A';
		    for ($n = 0; $n < $m; $n++) {
		        $str[$n]= $objPHPExcel->getActiveSheet()->getCell("$k$j")->getValue();//read the value
		        $k++;
		    }
		    // print_r($str); echo $n;exit;
		    foreach($column as $key => $value){
				foreach ($str as $k2=>$v2){
				    if ($key == $k2){
					  unset($str[$key]);
					  $str[$value]=$v2;
					}
				}	 
			}
			$data = $str;
			$mysql->insert($table, $data);
		}
		header('Location: admindatabasemanage.php');	
	}

	$mysql->showtables();
	$allrow = $mysql->fetchAll();
	// print_r($row); exit();
	$length=3;  
    $pagenum=@$_GET['page']?$_GET['page']:1; 
    $arrtot=count($allrow);
    $pagetot=ceil($arrtot/$length); 
    if($pagenum>=$pagetot){  
        $pagenum=$pagetot;  
        }  
        $offset=($pagenum-1)*$length;
        $i = 0;
        $row = array();
        while(($i<$length)&&($offset<$arrtot)){
        	$row[$i] = $allrow[$offset];
        	// print_r ($allrow[$offset]);echo '</br>';
        	// print_r ($row[$i]);echo '</br>';
        	$offset ++;
        	$i ++;
        	// echo $i;echo '</br>';
        	// echo $offset;echo '</br>';
        }
	require(ROOT.'/view/admin/admindatabasemanage.html');
	}

$mysql->close();

?>
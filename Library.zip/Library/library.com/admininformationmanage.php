<?php

require_once './lib/init.php';


	/* link the database */
	$mysql = new mysql();
	$mysql->connect();

//print_r($_POST); exit();
if(!acc()){
	header('Location: admin.php');
	} else if(empty($_GET)){
		header('Location: adminaccountsmanage.php');
	}else{
	// print_r($_POST);exit();
	if(!empty($_POST)) {
	$insert['First_name'] = trim($_POST['First_name']);
	$insert['Last_name'] = trim($_POST['Last_name']);
	$insert['Age'] = trim($_POST['Age']);
	$insert['Tel_number'] = trim($_POST['Tel_number']);
	$insert['Email'] = trim($_POST['Email']);
	$insert['Address'] = trim($_POST['Address']);
	$condition = trim($_GET['account']);

	$table = 'Borrower';//数据表
	$data = array(
	  'First_name' => $insert['First_name'],
	  'Last_name' => $insert['Last_name'],
	  'Age' => $insert['Age'],
	  'Tel_number' => $insert['Tel_number'],
	  'Email' => $insert['Email'],
	  'Address' => $insert['Address']
	);
	$where = 'Card_id = ' . $condition;
	$rows = $mysql->update($table, $data, $where);
	}

	$search['name'] = trim($_GET['account']);
	$field = array('First_name', 'Last_name', 'Age', 'Tel_number', 'Email', 'Address'); 
	$table = 'Borrower';
	$where = 'Card_id = '.$search['name'];
	$mysql->select($table, $field,$where);
	$row = $mysql->fetchArray();

	require(ROOT.'/view/admin/admininformationmanage.html');
	
}

$mysql->close();
?>
<?php

require_once './lib/init.php';
/* link the database */

if(!acc()) {
	header('Location: service.php');
	} else {
	$mysql = new mysql();
	$mysql->connect();
	$search['name'] = trim($_COOKIE['name']);

	$field = array('Title', 'Book_id', 'Due_date', 'Date_out'); 
	$table = 'Borrow left join Books on (Borrow.B_id=Books.Book_id)';
	$where = 'Card_id = '.$search['name'];
	$mysql->select($table, $field,$where);
	$row = $mysql->fetchAll();
	//print_r($row);exit();

	require(ROOT.'/view/admin/usermanage.html');
	
}

$mysql->close();

?>
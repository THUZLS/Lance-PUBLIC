<?php 

//echo md5('AdminGoTigers'); exit();
require_once './lib/init.php';

/* link the database */
$mysql = new mysql();
$mysql->connect();

if(empty($_GET)) {
	require(ROOT . '/view/front/search.html');
	} else {
	$search['name'] = trim($_GET['condition']);
	if(empty($search['name'])) {
		error3('Please enter a search condition!');
	}

	$field = array('Title', 'Book_id', 'Pub_name', 'Year', 'Available'); 
	$table = 'Books left join Publisher on (Books.Pub_id=Publisher.Pub_id)';
	$where = 'Books.Title LIKE \'%'.$search['name'].'%\'';
	$mysql->select($table, $field,$where);
	$allrow = $mysql->fetchAll();
	// print_r($allrow);exit();
	if(!$allrow) {
		error3('Sorry,  we can\'t find the result!');
	} else {
		$length=10;  
        $pagenum=@$_GET['page']?$_GET['page']:1; 
        $arrtot=count($allrow);
        $pagetot=ceil($arrtot/$length); 
        // echo $pagetot; exit();
        if($pagenum>=$pagetot){  
        $pagenum=$pagetot;  
        }  
        $offset=($pagenum-1)*$length;
        $pagewhere = 'Books.Title LIKE \'%'.$search['name'].'%\' order by Book_id limit '.$offset.','.$length;
        $mysql->select($table, $field,$pagewhere);
	    $row = $mysql->fetchAll();
	    $searchcondition = $search['name'];
	    $choose = 1;


		require(ROOT.'/view/front/bookshow.html');
		// setcookie('BookName' , $row['Title'], time()+10);
		// setcookie('ISBN' , $row['ISBN'], time()+10);
		// setcookie('Publisher' , $row['Pub_name']);
		// setcookie('Year' , $row['Year']);
		// setcookie('Available' , $row['Available']);
		//header('Location: bookshow.php?BookName='.$row['Title'].'&ISBN='.$row['ISBN'].'&Publisher='.$row['Pub_name'].'&Year='.$row['Year'].'&Available='.$row['Available']);
	}
}

$mysql->close();
?>
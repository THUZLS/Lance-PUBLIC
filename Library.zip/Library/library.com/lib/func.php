<?php 

/**
* error information
*/

function error($res) {
	$result = 'fail';
	echo "<script>alert('$res');</script>";
	require(ROOT . '/view/front/service.html');
	exit();
}


/**
* error information
*/

function error2($res) {
	$result = 'fail';
	echo "<script>alert('$res');</script>";
	require(ROOT . '/view/front/admin.html');
	exit();
}


/**
* error information
*/

function error3($res) {
	$result = 'fail';
	echo "<script>alert('$res');</script>";
	require(ROOT . '/view/front/search.html');
	exit();
}


/**
* error information
*/

function error4($res) {
	$result = 'fail';
	echo "<script>alert('$res');</script>";
	header('Location: admindatabasemanage.php');
	exit();
}


/**
* Encrypt user name
* @param str $name 
* @return str md5(username+salt)=>md5 code
*/

function cCode($name) {
	$salt = require(ROOT . '/lib/config.php');
	return md5($name . '|' . $salt['salt']);
}


/**
* Test the cookie
*/

function acc() {
	if(!isset($_COOKIE['name']) || !isset($_COOKIE['ccode'])){
		return false;
	}
	return $_COOKIE['ccode'] === cCode($_COOKIE['name']);
}


/**
* Remove redundant items
*/
function more_array_unique($arr=array()){  
    foreach($arr[0] as $k => $v){  
        $arr_inner_key[]= $k;     
    }  
    foreach ($arr as $k => $v){  
        $v =join(",",$v);      
        $temp[] =$v;        
    }  
    // printf("After split the array:<br>");  
    // print_r($temp);      
    //echo"<br/>";  
    $temp =array_unique($temp);      
    foreach ($temp as $k => $v){  
        $a = explode(",",$v);    
        $arr_after[]= array_combine($arr_inner_key,$a);    
    }  
      
    return$arr_after;  
}  

?>
<?php
require_once 'init.php';
/* 配置连接参数 */
// $config = array(
//   'type' => 'mysql',
//   'host' => '127.0.0.1',
//   'username' => 'root',
//   'password' => 'SA16225427',
//   'database' => 'test',
//   'charset' => 'gdb'
// //  'port' => '80'
// );
/* link the database */
$mysql = new mysql();
$mysql->connect();
/* Data Manipulate */
//1、Query all
$table = 'msg';//table
$num = $mysql->select($table);
echo 'Query' . $num . 'pieces data in total<br/>';
print_r($mysql->fetchAll());
echo '<br/>';
//2、Query part
$field = array('id', 'content'); 
$where = 'content = \'test \'';          //过滤条件
$mysql->select($table, $field, $where);
print_r($mysql->fetchAll());
echo '<br/>';
// Insert data
$table = 'msg';
$data = array(  //data array
  'id' => '5',
  'content' => sha1('test')
);
$id = $mysql->insert($table, $data);
echo 'The ID of the insert data is ' . $id;
echo '<br/>';
//Update data
$table = 'msg';//数据表
$data = array(
  'content' => 'change'
);
$where = 'id = 1';
$rows = $mysql->update($table, $data, $where);
echo 'The number of effected data is ' . $rows . 'pieces';
echo '<br/>';
//Delete data
$table = 'msg';
$where = 'id = 4';
$rows = $mysql->delete($table, $where);
echo 'Delete' . $rows . 'pieces data';

$mysql->close();
?>

<?php


class Mysql
{
  private $mysqli;
  private $result;


  /**
   * Link the database
   * @param $config 
   */
  public function connect()
  {
    $config = require(ROOT . '/lib/config.php');
    $host = $config['host'];  
    $username = $config['username'];
    $password = $config['password'];
    $database = $config['database'];
    $charset  = $config['charset'];
//  $port = $config['port']; 

    static $mysqli = null;
    if ($this->mysqli === null){
        $this->mysqli = new mysqli($host, $username, $password, $database);
        $this->mysqli->query("set names $charset");
    }
    
  }


  /**
   * Query the table
   * @return $table
   */
  public function showtables()
  {
    $sql = "SHOW TABLES";
    $this->result = $this->mysqli->query($sql);
    return $this->result->num_rows;
  }


/**
   * Query the colums
   * @return $colums
   */
  public function showcolums($table)
  {
    $sql = " select COLUMN_NAME from information_schema.COLUMNS where table_name = '{$table}'";
    // echo $sql;exit();
    $this->result = $this->mysqli->query($sql);
    // print_r($this->result);exit();
    return $this->result->num_rows;
  }


  /**
   * Query the data
   * @param $table 
   * @param null $field
   * @param null $where
   * @return mixed  Number of the result
   */
  public function select($table, $field = null, $where = null)
  {
    $sql = "SELECT * FROM {$table}";
    if (!empty($field)) {
      $field = '`' . implode('`,`', $field) . '`';
      $sql = str_replace('*', $field, $sql);
    }
    if (!empty($where)) {
      $sql = $sql . ' WHERE ' . $where;
    }
    // echo $sql;exit();
    $this->result = $this->mysqli->query($sql);
    return $this->result->num_rows;
  }


  /**
   * @return mixed Get the all information of the result 
   */
  public function fetchAll()
  {
   //return $this->result->fetch_all(MYSQLI_ASSOC);
    $results_array = array();
    while ($row = $this->result->fetch_assoc()) {
      $results_array[] = $row;
    }
    return $results_array;
  }


  /**
   * @return mixed Get the array information of the result 
   */
  public function fetchArray()
  {
    return $this->result->fetch_array(MYSQLI_ASSOC);
  }


  /**
   * Insert data
   * @param $table
   * @param $data 
   * @return mixed insert_id
   */
  public function insert($table, $data)
  {
    foreach ($data as $key => $value) {
      $data[$key] = $this->mysqli->real_escape_string($value);
    }
    $keys = '`' . implode('`,`', array_keys($data)) . '`';
    $values = '\'' . implode("','", array_values($data)) . '\'';
    $sql = "INSERT INTO {$table}( {$keys} )VALUES( {$values} )";
    $this->mysqli->query($sql);
    return $this->mysqli->insert_id;
  }


  /**
   * Update the data
   * @param $table
   * @param $data 
   * @param $where
   * @return mixed affected_rows
   */
  public function update($table, $data, $where)
  {
    foreach ($data as $key => $value) {
      $data[$key] = $this->mysqli->real_escape_string($value);
    }
    $sets = array();
    foreach ($data as $key => $value) {
      $kstr = '`' . $key . '`';
      $vstr = '\'' . $value . '\'';
      array_push($sets, $kstr . '=' . $vstr);
    }
    $kav = implode(',', $sets);
    $sql = "UPDATE {$table} SET {$kav} WHERE {$where}";
    //echo $sql;exit();
    $this->mysqli->query($sql);
    return $this->mysqli->affected_rows;
  }


  /**
   * Delete data
   * @param $table
   * @param $where 
   * @return mixed affected_rows
   */
  public function delete($table, $where = null)
  {
    $sql = empty($where) ? "DELETE FROM {$table}" : "DELETE FROM {$table} WHERE {$where}";
    // echo $sql; exit();
    $this->mysqli->query($sql);
    return $this->mysqli->affected_rows;
  }


   /**
   * Close the link
   *  
   */
  public function close()
  {
    
    $this->result->free();
    $this->mysqli->close();

    
  }

}



?>
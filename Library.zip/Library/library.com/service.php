<?php
require_once './lib/init.php';
if(acc()) {
	header('Location: usermanage.php');
	} else {
		require_once './lib/init.php';
		require(ROOT.'/view/front/service.html');
	}

?>
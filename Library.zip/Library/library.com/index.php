<?php
require_once './lib/init.php';
require(ROOT.'/view/front/index.html');



?>
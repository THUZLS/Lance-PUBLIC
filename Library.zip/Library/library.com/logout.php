<?php 

setcookie('name',null,0);
header('Location: userlogin.php');



?>
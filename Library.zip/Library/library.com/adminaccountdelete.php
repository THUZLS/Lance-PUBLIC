<?php

require_once './lib/init.php';


	/* link the database */
	$mysql = new mysql();
	$mysql->connect();

//print_r($_POST); exit();
if(!acc()){
	header('Location: admin.php');
	} else if(empty($_GET)){
		header('Location: adminaccountsmanage.php');
	}else{
	$table = 'Borrower';
	$condition = trim($_GET['account']);
	$where = 'Card_id = ' . $condition;
	$rows = $mysql->delete($table, $where);

	header('Location: adminaccountsmanage.php');
	
}

$mysql->close();
?>
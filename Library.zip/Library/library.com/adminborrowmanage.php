<?php

require_once './lib/init.php';
/* link the database */

if(!acc()) {
	header('Location: admin.php');
	} else {
		// print_r($_POST);print_r($_GET);echo !empty($_POST);exit();
		if(!empty($_POST)) {
			$mysql = new mysql();
			$mysql->connect();
			$condition = trim($_GET['condition']);
			$BookID = trim($_POST['BookID']);
			$UserID = trim($_POST['UserID']);
			if($condition === 'return'){
				$table = 'Books';
				$where = 'Book_id = ' . $BookID;
				$field = null;
				$mysql->select($table, $field, $where);
				$row = $mysql->fetchArray();
				$row['Available'] = 1;
				$row['Copy']++;
				// $data = array(
				//   'Book_id' => $row['Book_id'],
				//   'Pub_id' => $row['Pub_id'],
				//   'Copy' => $row['Copy'],
				//   'Available' => $row['Available'],
				//   'ISBN' => $row['ISBN'],
				//   'Category' => $row['Category'],
				//   'Title' => $row['Title'],
				//   'Year' => $row['Year']
				// );
				$data = $row;
				$rows = $mysql->update($table, $data, $where);
				$table = 'Borrow';
				$where = 'Card_id = ' . $UserID . ' and B_id = ' . $BookID;
				$mysql->delete($table, $where);
			}else{
				$table = 'Books';
				$where = 'Book_id = ' . $BookID;
				$field = null;
				$mysql->select($table, $field, $where);
				$row = $mysql->fetchArray();
				// print_r($row);exit();
				$row['Copy']--;
				$row['Available'] = ($row['Copy']>0) ? 1 : 0;
				$data = $row;
				$rows = $mysql->update($table, $data, $where);
				$table = 'Reservation';
				$where = 'Card_id = ' . $UserID . ' and Book_id = ' . $BookID;
				$mysql->delete($table, $where);
		        date_default_timezone_set('EST');
		        $Duedate = date("d/m/y");
		        $Dateout = date('d/m/y',strtotime('+1 month'));
		        // echo $Duedate, $Dateout;exit();
		        $data2 = array(
				  'B_id' => $BookID,
				  'Card_id' => $UserID,
				  'Due_date' => $Duedate,
				  'Date_out' => $Dateout
				);
		        $table2 = 'Borrow';
		        $mysql->insert($table2, $data2);

			}
			$mysql->close();
		}
		


		
	require(ROOT.'/view/admin/adminborrowmanage.html');
	}


?>
<?php 
/****
Library Management System
by Lance Zhang
(c) Lance Zhang
****/

//echo md5('AdminGoTigers'); exit();
require_once './lib/init.php';

/* link the database */
$mysql = new mysql();
$mysql->connect();

if(empty($_GET)) {
	require(ROOT . '/view/front/search.html');
	} else {
	$search['Book_id'] = trim($_GET['book_id']);
	$search['Title'] = trim($_GET['bookname']);
	$search['Category'] = trim($_GET['subject']);
	$search['Author'] = trim($_GET['author']);
	$search['Pub_name'] = trim($_GET['publisher']);

	if(empty($search['Book_id'])&&$search['Title']&&$search['Category']&&$search['Author']&&$search['Pub_name']) {
		error3('Please enter a search condition!');
	}

	$field = array('Title', 'Book_id', 'Pub_name', 'Year', 'Available'); 
	$table = 'Books left join Publisher on (Books.Pub_id=Publisher.Pub_id) left join Author_books on (Books.Book_id=Author_books.BookID) left join Author on (Author_books.Author_id=Author.Author_id)';
	//get the search conditon
	$condition1 = empty($search['Book_id']) ? 'true' : ('Books.Book_id LIKE \'%'.$search['Book_id'].'%\'');
	$condition2 = empty($search['Title']) ? 'true' : ('Books.Title LIKE \'%'.$search['Title'].'%\'');
	$condition3 = empty($search['Category']) ? 'true' : ('Books.Category LIKE \'%'.$search['Category'].'%\'');
	$condition4 = empty($search['Author']) ? 'true' : ('Author.First_name  LIKE \'%'.$search['Author'].'%\'' . ' OR Author.Last_name  LIKE \'%'.$search['Author'].'%\'');
	$condition5 = empty($search['Pub_name']) ? 'true' : ('Publisher.Pub_name LIKE \'%'.$search['Pub_name'].'%\'');
	$where = $condition1 . ' and ' . $condition2 . ' and ' . $condition3 . ' and ' . $condition4 . ' and ' . $condition5;
	$mysql->select($table, $field,$where);
	$totalrow = $mysql->fetchAll();
	$allrow = more_array_unique($totalrow);
	// print_r($allrow);//exit();
	if(!$allrow) {
		error3('Sorry,  we can\'t find the result!');
	} else {
		$length=10;  
        $pagenum=@$_GET['page']?$_GET['page']:1; 
        $arrtot=count($allrow);
        $pagetot=ceil($arrtot/$length); 
        // echo $pagetot; exit();
        if($pagenum>=$pagetot){  
        $pagenum=$pagetot;  
        }  
        $offset=($pagenum-1)*$length;
        $i = 0;
        $row = array();
        while(($i<$length)&&($offset<$arrtot)){
        	$row[$i] = $allrow[$offset];  // displayed by page number
        	$offset ++;
        	$i ++;
        }
        
	    $choose = 0;
	    $searchBook_id = $search['Book_id'];
	    $searchTitle = $search['Title'];
	    $searchCategory = $search['Category'];
	    $searchAuthor = $search['Author'];
	    $searchPub_name = $search['Pub_name'];


		require(ROOT.'/view/front/bookshow.html');
	}
}

$mysql->close();
?>
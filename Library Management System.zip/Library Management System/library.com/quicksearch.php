<?php 
/****
Library Management System
by Lance Zhang
(c) Lance Zhang
****/

require_once './lib/init.php';

/* link the database */
$mysql = new mysql();
$mysql->connect();

if(empty($_GET)) {
	require(ROOT . '/view/front/search.html');
	} else {
	$search['name'] = trim($_GET['condition']);
	if(empty($search['name'])) {
		error3('Please enter a search condition!');
	}

	$field = array('Title', 'Book_id', 'Pub_name', 'Year', 'Available'); 
	$table = 'Books left join Publisher on (Books.Pub_id=Publisher.Pub_id)';
	$where = 'Books.Title LIKE \'%'.$search['name'].'%\'';//search condition
	$mysql->select($table, $field,$where);
	$allrow = $mysql->fetchAll();
	// print_r($allrow);exit();
	if(!$allrow) {
		error3('Sorry,  we can\'t find the result!');
	} else {
		$length=10;  
        $pagenum=@$_GET['page']?$_GET['page']:1; 
        $arrtot=count($allrow);
        $pagetot=ceil($arrtot/$length); 
        if($pagenum>=$pagetot){  
        $pagenum=$pagetot;  
        }  
        $offset=($pagenum-1)*$length;
        $pagewhere = 'Books.Title LIKE \'%'.$search['name'].'%\' order by Book_id limit '.$offset.','.$length;
        $mysql->select($table, $field,$pagewhere);//search the books
	    $row = $mysql->fetchAll();
	    $searchcondition = $search['name'];
	    $choose = 1;


		require(ROOT.'/view/front/bookshow.html');

	}
}

$mysql->close();
?>
<?php
/****
Library Management System
by Lance Zhang
(c) Lance Zhang
****/
require_once './lib/init.php';
require(ROOT.'/view/front/about.html');



?>
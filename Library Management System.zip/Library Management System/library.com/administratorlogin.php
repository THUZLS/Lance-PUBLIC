<?php 
/****
Library Management System
by Lance Zhang
(c) Lance Zhang
****/

require_once './lib/init.php';

/* link the database */
$mysql = new mysql();
$mysql->connect();


if(empty($_POST)) {
	require(ROOT . '/view/front/admin.html');
	} else {
	$user['name'] = trim($_POST['Username']);
	if(empty($user['name'])) {
		error2('Please enter a card ID!');
	}

	$user['Password'] = trim($_POST['Password']);
	if(empty($user['Password'])) {
		error2('Please enter a password!');
	}

	//$sql = "select * from user where name='$user[name]' and password='$user[password]'";
	$table = 'Administrator';
	$where = 'Username = \''. $user['name'] . '\'';
	$mysql->select($table, null,$where);//look for the account information
	$row = $mysql->fetchArray();
	// print_r($row);
 //    echo md5($user['Password'].$row['salt']);
	// exit();
	if(!$row) {
		error2('The cardID is not exit!');
	} else {                                 //set the cookies
		if(md5($user['Password'].$row['salt']) === $row['Password']){
			setcookie('name' , $user['name']);
			setcookie('ccode' , cCode($user['name']));
			header('Location: adminaccountsmanage.php');
		} else {
			error2('Sorry, the password is wrong!');
		}
	}
}

$mysql->close();
?>
<?php 
/****
Library Management System
by Lance Zhang
(c) Lance Zhang
****/

require_once './lib/init.php';

/* link the database */
$mysql = new mysql();
$mysql->connect();

if(empty($_POST)) {
	require(ROOT . '/view/front/service.html');
	} else {
	$Card_id = trim($_POST['CardID']);
	if(empty($Card_id)) {
		error('Please enter a card ID!');
	}

	$Email = trim($_POST['Email']);
	if(empty($Email)) {
		error('Please enter an email!');
	}

	$str = (trim($_POST['Password']));
	if(empty($str)) {
		error('Please enter a password!');
	}
    if(preg_match('/^[a-z0-9]+$/', $str)){
        error('The password should include at least one capital letter!');  
    } 
              
    $Password = md5($str.'GoTigers');

	$PhoneNumber = trim($_POST['PhoneNumber']);
	if(empty($PhoneNumber)) {
		error('Please enter a password!');
	}

	$table = 'Borrower';
	$data = array(          //get the signup data
	'Card_id' => $Card_id,
	'First_name' => null,
	'Last_name' => null,
	'Age' => null,
	'Password' => $Password,
	'Tel_number' => $PhoneNumber,
	'Email'   => $Email,
	'Address' => null,
	'salt' => 'GoTigers'
	);
	$id = $mysql->insert($table, $data);


	//$sql = "select * from user where name='$user[name]' and password='$user[password]'";
	
	if( $id === null ) {
		error('Fail to sign up!');
	} else {                          //set the cookies
		setcookie('name' , $Card_id);
		setcookie('ccode' , cCode($Card_id));
		echo "<script>alert('Congratulations! Sign up successfully! Please improve personal information!');</script>";
		// header('Location: userprofile.php');
		require(ROOT . '/view/admin/userprofile.html');
	}
}

$mysql->close();
?>
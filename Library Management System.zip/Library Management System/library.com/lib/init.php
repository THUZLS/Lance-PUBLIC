<?php
/****
Library Management System
by Lance Zhang
(c) Lance Zhang
****/


/****
 *initialization files 
 *
 ****/

define('ROOT', dirname(__DIR__));
require(ROOT . '/lib/mysql.php');
require(ROOT . '/lib/func.php');

?>
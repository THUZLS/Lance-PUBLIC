<?php

/****
Library Management System
by Lance Zhang
(c) Lance Zhang
****/

/****
 *database config information
 *
 ****/


return array(
'type' => 'mysql',
'host' => 'mysql1.cs.clemson.edu',
'username' => 'Lance',
'password' => 'SA16225427',
'database' => 'ZLS',
'charset' => 'gdb',
'salt'=>'GoTigers'
//  'port' => '80'
);

?>

<?php 
/****
Library Management System
by Lance Zhang
(c) Lance Zhang
****/

require_once './lib/init.php';

/* link the database */
$mysql = new mysql();
$mysql->connect();
//print_r($_POST);exit();

if(empty($_POST)) {
	require(ROOT . '/view/front/search.html');
	} else {
	$reservation['Card_id'] = trim($_POST['UserID']);
	if(empty($reservation['Card_id'])) {
		error3('Please enter a card ID!');
	}

	$reservation['Book_id'] = trim($_POST['BookID']);
	if(empty($reservation['Book_id'])) {
		error('Please enter a book!');
	}

	//check if the user has logged in
	if(!acc()){
		header('Location: service.php');
	}

	//$sql = "select * from reservation where Card_id='$reservation[Card_id]' and password='$reservation[password]'";
	$table = 'Reservation';
	$data = array(  //data array
	  'Book_id' => $reservation['Book_id'],
	  'Card_id' => $reservation['Card_id']
	);
	$id = $mysql->insert($table, $data);

	if($id === null){
		header('Location: search.php');
	}else{
		header('Location: usermanage.php');
	}
	
}

$mysql->close();
?>
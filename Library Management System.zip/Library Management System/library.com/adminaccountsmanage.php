<?php
/****
Library Management System
by Lance Zhang
(c) Lance Zhang
****/

require_once './lib/init.php';
/* link the database */

if(!acc()) {
	header('Location: admin.php');
	} else {
	$mysql = new mysql();
	$mysql->connect();
	if (!empty($_GET['account'])){
		$search['name'] = trim($_GET['account']);
		$where = 'Card_id = '.$search['name'];
	}else{
		$where = null;
	}

	$field = array('First_name', 'Last_name', 'Tel_number', 'Email', 'Card_id'); 
	$table = 'Borrower';
	$mysql->select($table, $field,$where);
	$allrow = $mysql->fetchAll();//get the accounts information
	//print_r($row);exit();
	// echo $where;exit();

	
	if(empty($where)){
		$length=10;  
        $pagenum=@$_GET['page']?$_GET['page']:1; 
        $arrtot=count($allrow);
        $pagetot=ceil($arrtot/$length); 
        // echo $pagetot; exit();
        if($pagenum>=$pagetot){  
        $pagenum=$pagetot;  
        }  
        $offset=($pagenum-1)*$length;
        $pagetable = $table .' order by Card_id limit '.$offset.','.$length;// displayed by page number
        $mysql->select($pagetable, $field);
	    $row = $mysql->fetchAll();
	    $searchcondition = null;
		require(ROOT.'/view/admin/adminaccountsmanage.html');
	}else{
		$row = $allrow;
		$searchcondition = $search['name'];
		$pagenum = 0;
		// print_r($row);exit();
		require(ROOT.'/view/admin/adminaccountsmanage.html');
	}
	
}

$mysql->close();

?>
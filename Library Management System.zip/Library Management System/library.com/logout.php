<?php 
/****
Library Management System
by Lance Zhang
(c) Lance Zhang
****/

setcookie('name',null,0);
header('Location: userlogin.php');



?>